import {formatDate } from '@angular/common';

export class ToDo {
    _id:string;
    title: string;
    comments:string[] ;
    date: Date;
    status: string;
    constructor( ) {
        this.title = ""
        this.comments = []
        this.date =  new Date();
        this.status = ""
    }
}
