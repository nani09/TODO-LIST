import { Component, OnInit, HostListener } from '@angular/core';
import {formatDate } from '@angular/common';
import { TodoService } from '../services/todo.service';
import {ToDo} from '../models/todo.model';



@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  count =0;
  title: string = "";
  cardTitle = "";
  sidebar: boolean = false;
  today= new Date();
  reqDateFormat:any;
  newTodo: ToDo = new ToDo();
  todosList: ToDo[];
  displayDate: string;
  comment:string;
  currentTodo: ToDo;

  constructor(private todoService: TodoService) {
    this.displayDate = formatDate(this.today, 'MMM d, y', 'en-IN', '');
    this.reqDateFormat = formatDate(this.today, 'dd-MM-yyyy', 'en-IN', '');
  }

  ngOnInit() {

    this.todoService.getToDos()
      .subscribe(todos => {
        this.todosList = todos
    })
  }


  public onKey(event) {
    if(event.keyCode == 13) {
      this.addTask();
    }
  }

  public openSidebar(event,todo) {
    this.currentTodo = todo;
    this.sidebar = true;
    this.cardTitle = todo.title;  
    
  }

  public addTask() {
    this.newTodo.title = this.title;
    this.title = "";
    this.todoService.createTodo(this.newTodo)
      .subscribe((res) => {
        this.todosList.push(res.data) 
        this.newTodo = new ToDo()
      })
  }

  public removeTodo(todo) {
    this.currentTodo = new ToDo() 
    const id = todo._id
    this.todoService.deleteTodo(id)
    .subscribe((res) => {
      this.sidebar = false; 
      this.todosList.splice(this.todosList.indexOf(todo), 1)
    })
   }

   public updateTodoComments() {
     
    this.currentTodo.comments.push(this.comment);
    try {
      this.todoService.updateComments(this.currentTodo)
      .subscribe((res) => {  
        this.comment = "";
        })
     }catch (error) {
      console.log(error)
    }
  }

  public removeComment(comment) {
    let arr = this.currentTodo.comments;
    arr.splice(arr.indexOf(comment), 1);
    this.currentTodo.comments = arr;
    this.todoService.updateComments(this.currentTodo)
      .subscribe((res) => {

      })
  }

  public addComment(event) {
    if(event.keyCode == 13) {
      this.updateTodoComments();
    }
  }
  @HostListener('sendTodo')
  sendTodo(todo) {
    this.todoService.getCurrentTodo(todo);
  }
}
