import { Component, OnInit } from '@angular/core';
import {formatDate } from '@angular/common';
import { TodoService } from '../services/todo.service';
import {ToDo} from '../models/todo.model';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {
  title="Title";
  date = new Date();
  comment = "";
  comments = [];
  currentTodo: ToDo;
  flag: boolean = false;

  constructor(private todoService: TodoService) {
   }

  ngOnInit() {
    this.todoService.passCurrentTodo.subscribe( mycurrentTodo => {
      this.currentTodo = mycurrentTodo;      
      console.log(this.currentTodo)
      if(this.currentTodo.comments.length > 0) {
        console.log("flag")
        this.flag = true;
      }
    })
  }
  
  public updateTodoComments() {
    if (this.flag) {
      // console.log("current todo $$$$$$$", this.currentTodo)
      this.currentTodo.comments.push(this.comment);
      try {
        this.todoService.updateComments(this.currentTodo)
        .subscribe((res) => {  
          this.comment = "";
        })
      }catch (error) {
        console.log(error)
      }
    }
  }
  
  public addComment(event) {
    // console.log(this.currentTodo);
    // console.log(this.flag)
    if(event.keyCode == 13) {
      this.updateTodoComments();
    }
  }

}
