import {ToDo} from '../models/todo.model';
import { Observable } from 'rxjs';
import { HttpClient, HttpErrorResponse, HttpClientModule } from '@angular/common/http';
import { map } from 'rxjs/operators';
import {Output, EventEmitter} from '@angular/core'
// import { from } from 'rxjs';

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class TodoService {

  api_url = 'http://localhost:3000';
  todoUrl = `${this.api_url}/api/todos`;
  // todo:ToDo;
  @Output() passCurrentTodo: EventEmitter<ToDo> = new EventEmitter();
 
  constructor( private http: HttpClient ) {

   }

   createTodo(todo: ToDo): Observable<any>{
    return this.http.post(`${this.todoUrl}`, todo);
  }

   getToDos(): Observable<ToDo[]>{
    return this.http.get(this.todoUrl).pipe(
      map(res  => {
        return res["data"].docs as ToDo[];
      })
    )
  }

  deleteTodo(id:string):any{
    let deleteUrl = `${this.todoUrl}/${id}`
    return this.http.delete(deleteUrl).pipe(
      map(res  => {
        return res;
      })
    )
  }

  updateComments(todo:ToDo):Observable<any>{
    console.log(todo)
    return this.http.put(`${this.todoUrl}`,todo);
  }


  getCurrentTodo(todo) {
    this.passCurrentTodo.emit(todo)
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }

}
